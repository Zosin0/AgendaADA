## AgendaADA

### Este repo tem o objetivo de apresentar o projeto do grupo 6 do curso de Angular.
---
#### Integrantes:
- Rafael Yoshida 
- Lucas Zoser
- Bruno Favalli
- Gabriel Silva
- Janael Martins
---


